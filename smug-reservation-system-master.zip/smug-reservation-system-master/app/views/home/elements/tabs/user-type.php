<!-- Generate report tab -->
<li role="presentation" class="unactive text-center">
	<a href="#user-type" role="tab" data-toggle="tab">Control User Type</a>
</li>
