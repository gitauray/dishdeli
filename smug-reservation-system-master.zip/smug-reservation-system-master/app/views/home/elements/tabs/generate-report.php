<!-- Generate report tab -->
<li role="presentation" class="unactive text-center">
	<a href="#report" role="tab" data-toggle="tab">Generate Report</a>
</li>
