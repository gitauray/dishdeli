<!-- Cancel Reservation confirmation starts -->
<div class="floating-card alert-message col-md-6 col-md-offset-3 col-xs-10 col-xs-offset-1" id="reservation-cancel-message">
	<h2 class="text-center">Are you sure that you want to cancel the reservation?</h2>

	<button class="discard col-md-2 col-xs-2 col-md-offset-2 col-xs-offset-3" onclick="discard();">Discard</button>

	<button class="filled button col-md-2 col-xs-2 col-md-offset-6 col-xs-offset-7" onclick="hide(alertMessage); hide(background);">Cancel Reservation</button>
</div>
