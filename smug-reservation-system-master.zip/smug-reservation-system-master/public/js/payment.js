/*$(document).ready(function(){
    $("#checkout").click(function () {
        var dat = [];
        for (var counter = 0; counter < shoppingCart.length; counter++)
        {
            dat.push({
                name: shoppingCart[counter][0],
                amount: shoppingCart[counter][1]
            });
        }
        console.log(dat);
        /*hide("#invoice-card");
        hide(floatingButton);
        updateShoppingCartNumber();
        $.post("?url=Foodmenu/makeOrder", {
            ss: JSON.stringify(dat),
            address:$("#address").val(),
            paymentmethod:$("#payment-method-select").val(),
            credit_number:$("#credit-card-number-text").val(),
            cvc:$("#cvc-text").val(),
            expire_date:$("#expire-date-text").val(),
        }, function (data) {
            console.log(data);

        });
    });
});*/
