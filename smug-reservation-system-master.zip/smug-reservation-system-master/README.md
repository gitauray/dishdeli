# SMUG Reservation System

This is a college's project, made by students. Written in HTML, CSS, JavaScript, jQuery and PHP. The project isn't completed it's missing a lot of stuff, has a lot of design flows and bugs. We want to upload it to share our work and get feedback from the community to learn more and provide our code as an open source to help other people create their stuff faster and easily.

There is some stuff to care about:
- You need to deploy the database into your PHPMyAdmin first (.sql file is provided in the repository)
- There are a lot of functions that aren't completed yet, so if you finish it. You are more than welcome to share it with us
- Most of the code isn't well formatted, we will work on it as soon as possible

You can find the project on [Behance] (http://bit.ly/smugDesign)

# This is our team:
Muhammad Tarek 
- Email: muhammadtarek96@gmail.com
- [Facebook](https://www.facebook.com/m.tarek96)
- [Twitter](https://twitter.com/muhammad__tarek)
- [LinkedIn](https://eg.linkedin.com/in/muhammadtarek)
- [Behance](https://www.behance.net/muhammad96)

Muhammad Kamal
- Email: medoforever271@gmail.com
- [Facebook](https://www.facebook.com/mhmd.bashae1)
- [LinkedIn](https://eg.linkedin.com/in/mohamedkamal9)

Muhammad Al-Rifai
- Email: fcih.mohammed@gmail.com
- [Facebook](https://www.facebook.com/Mohammed.Alrfaae.II)

Mustafa Magdy
- Email: Mostafa.Magdy9696@gmail.com
- [Facebook](https://www.facebook.com/mostafa.magdy.9022662?hc_location=ufi)
- [LinkedIn](https://www.linkedin.com/in/mostafa-magdy-46a963ba?trk=nav_responsive_tab_profile)

Muhammad Khairala
- Email: khairala1996@gmail.com
- [Facebook] (https://www.facebook.com/mohammed.khairala)

Muhammad Ashraf
- Email: mohamed.fcih2265@gmail.com
- [Facebook] (https://www.facebook.com/mohamed.ashraf2265?fref=ufi)
- [LinkedIn] (https://www.linkedin.com/in/mohamed-ashraf-55b86b121)
