<?php echo get_header(); ?>
<div class="row content img_inner">
	<p class="text-center"><?php echo $text_logout_msg; ?></p>
</div>
<?php echo get_footer(); ?>